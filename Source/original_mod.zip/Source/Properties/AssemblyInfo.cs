﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Allgemeine Informationen über eine Assembly werden über die folgenden 
// Attribute gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die mit einer Assembly verknüpft sind.
[assembly: AssemblyTitle("Cthulhu")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Estate")]
[assembly: AssemblyCopyright("Copyright ©  2016-2017 (Jecrell)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("a8e081b6-8768-4fe9-817f-f0ee42cf13ef")]

[assembly: AssemblyVersion("1.1.0.7")]
[assembly: AssemblyFileVersion("1.1.0.7")]
